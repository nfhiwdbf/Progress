const { configDotenv } = require("dotenv");
const express = require("express");
const app = express();
const mongoose = require("mongoose");

require("dotenv").config();
app.use(express.json());

//connecting frontend with backend using cors

// app.use(cors);

// configDotenv();
const port = 8000;
app.get("/", (req, res) => {
  res.send("hello");
});

//port configuration//
app.listen(port, () => {
  console.log(`App is listening on port${port}`);
});
