import React from "react";
import styled from "styled-components";

const Navbar = () => {
  return (
    <NavContainer>
      <Logo>HOSPIDOCS</Logo>
      <NavLinks>
        <NavLink href="/">Home</NavLink>
        <NavLink href="/contact">Contact</NavLink>
        <NavLink href="/about">About Us</NavLink>
        <NavLink href="/login">Login</NavLink>
      </NavLinks>
    </NavContainer>
  );
};

export default Navbar;

const NavContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: #333;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
`;

const Logo = styled.h1`
  color: #fff;
  font-size: 1.8rem;
  font-weight: 600;
`;

const NavLinks = styled.div`
  display: flex;
  gap: 2rem;
`;

const NavLink = styled.a`
  color: #fff;
  text-decoration: none;
  font-size: 1.1rem;
  font-weight: 500;
  transition: color 0.3s ease;

  &:hover {
    color: #ff7f50;
  }

  &:active {
    color: #ff6347;
  }
`;
