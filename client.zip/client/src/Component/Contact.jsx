import React from "react";
import styled from "styled-components";
import Register from "./Register";

const Contact = () => {
  return (
    <PageContainer>
      <ContentContainer>
        <Title>Contact Us</Title>
        <Subtitle>We’d love to hear from you!</Subtitle>

        <InfoContainer>
          <Column>
            <h4>Follow Us</h4>
            <FooterLink href="https://facebook.com" target="_blank">
              <i className="fab fa-facebook-f" />
              <span>Facebook</span>
            </FooterLink>
            <FooterLink href="https://instagram.com" target="_blank">
              <i className="fab fa-instagram" />
              <span>Instagram</span>
            </FooterLink>
          </Column>

          <AddressContainer>
            <h3>Our Address</h3>
            <h5>Kathmandu, Nepal</h5>
          </AddressContainer>

          <EmailContainer>
            <h3>Email Us At:</h3>
            <h5>hospidocs@gmail.com</h5>
          </EmailContainer>
        </InfoContainer>

        <FormSection>
          <Register />
        </FormSection>
      </ContentContainer>
    </PageContainer>
  );
};

export default Contact;

const PageContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  min-height: 100vh;
  background: linear-gradient(to right, #6a11cb, #2575fc);
  padding-top: 80px; /* Offset to prevent overlap with navbar */
`;

const ContentContainer = styled.div`
  text-align: center;
  background-color: #fff;
  padding: 3rem;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  width: 90%;
  max-width: 900px;
  backdrop-filter: blur(10px);
`;

const Title = styled.h1`
  color: #333;
  margin-bottom: 15px;
  font-size: 2.5rem;
  font-weight: 700;
  letter-spacing: 1px;
`;

const Subtitle = styled.p`
  color: #555;
  margin-bottom: 30px;
  font-size: 1.2rem;
  font-weight: 500;
`;

const InfoContainer = styled.div`
  margin-bottom: 30px;
  display: flex;
  justify-content: space-evenly;
  flex-wrap: wrap;
  gap: 40px;
`;

const Column = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  max-width: 250px;
  margin-bottom: 20px;
`;

const FooterLink = styled.a`
  color: #333;
  font-size: 18px;
  text-decoration: none;
  margin: 15px 0;
  display: flex;
  align-items: center;
  transition: color 0.3s ease, transform 0.3s ease;

  &:hover {
    color: #ff6347;
    transform: scale(1.1);
  }

  i {
    margin-right: 8px;
  }

  span {
    font-size: 16px;
    font-weight: 500;
  }
`;

const AddressContainer = styled.div`
  width: 100%;
  max-width: 250px;
`;

const EmailContainer = styled.div`
  width: 100%;
  max-width: 250px;
`;

const FormSection = styled.div`
  margin-top: 40px;
  padding-top: 30px;
  background-color: #f9f9f9;
  border-top: 2px solid #eee;
  border-radius: 8px;
`;
