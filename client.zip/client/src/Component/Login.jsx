import React, { useState } from "react";
import styled from "styled-components";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLogin, setIsLogin] = useState(true); // Track login/signup state

  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle login/signup logic here
    console.log("Email:", email, "Password:", password);
  };

  return (
    <PageContainer>
      <Form onSubmit={handleSubmit}>
        <Title>{isLogin ? "Login" : "Signup"}</Title>

        <InputGroup>
          <Label htmlFor="email">Email:</Label>
          <Input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </InputGroup>

        <InputGroup>
          <Label htmlFor="password">Password:</Label>
          <Input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </InputGroup>

        {!isLogin && (
          <InputGroup>
            <Label htmlFor="confirmPassword">Confirm Password:</Label>
            <Input type="password" id="confirmPassword" required />
          </InputGroup>
        )}

        <Button type="submit">{isLogin ? "Login" : "Signup"}</Button>

        <ToggleLink onClick={() => setIsLogin(!isLogin)}>
          {isLogin
            ? "Don't have an account? Signup"
            : "Already have an account? Login"}
        </ToggleLink>
      </Form>
    </PageContainer>
  );
};

export default Login;

// Styled Components
const PageContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(to right, #ff7e5f, #feb47b);
`;

const Form = styled.form`
  background: #fff;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
  width: 100%;
  max-width: 350px;
  text-align: center;
`;

const Title = styled.h2`
  color: #333;
  margin-bottom: 20px;
  font-size: 1.8rem;
  font-weight: 600;
`;

const InputGroup = styled.div`
  margin-bottom: 20px;
  text-align: left;
`;

const Label = styled.label`
  color: #555;
  font-size: 0.9rem;
  margin-bottom: 5px;
  display: block;
`;

const Input = styled.input`
  width: 100%;
  padding: 12px;
  border: 2px solid #ddd;
  border-radius: 5px;
  font-size: 1rem;
  outline: none;
  transition: all 0.3s ease;

  &:focus {
    border-color: #feb47b;
    box-shadow: 0 0 5px rgba(254, 180, 123, 0.5);
  }
`;

const Button = styled.button`
  background: #113d31;
  color: #fff;
  border: none;
  padding: 12px;
  width: 100%;
  cursor: pointer;
  border-radius: 5px;
  font-size: 1.1rem;
  transition: background-color 0.3s ease, transform 0.2s ease;

  &:hover {
    background-color: #0f2c24;
    transform: scale(1.05);
  }
`;

const ToggleLink = styled.p`
  margin-top: 20px;
  color: #555;
  font-size: 0.9rem;
  cursor: pointer;
  text-decoration: underline;

  &:hover {
    color: #feb47b;
  }
`;
