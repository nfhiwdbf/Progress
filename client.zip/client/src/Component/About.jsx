import React from "react";

const About = () => {
  return (
    <div>
      <div class="about-section">
        <h1>About Us</h1>
        <p>This is a project by four of us.</p>
        <p>
          Resize the browser window to see that this page is responsive by the
          way.
        </p>
      </div>

      <h2>Our Team</h2>
      <div class="row">
        <div class="column">
          <div class="card">
            <img
              src="https://static.wikia.nocookie.net/villainous-benchmark/images/f/fa/Season_4_-_Jesse.webp/revision/latest/scale-to-width/360?cb=20240429123939"
              alt="Jane"
            />
            <div class="container">
              <h2>Manjil Bishwakarma</h2>
              <p class="title">Front end Designer</p>
              <p>3rd Year at Himalaya College of Engineering</p>
              <p>c7manjil@gmail.com</p>
              <p>
                <button class="button">Contact</button>
              </p>
            </div>
          </div>
        </div>

        <div class="column">
          <div class="card">
            <img src="https://static.wikia.nocookie.net/villainous-benchmark/images/f/fa/Season_4_-_Jesse.webp/revision/latest/scale-to-width/360?cb=20240429123939" />
            <div class="container">
              <h2>Riwaz Rayamajhi</h2>
              <p class="title">Front end Designer</p>
              <p>3rd Year at Himalaya College of Engineering</p>
              <p>riwazrayamajhi@gmail.com</p>
              <p>
                <button class="button">Contact</button>
              </p>
            </div>
          </div>
        </div>

        <div class="column">
          <div class="card">
            <img src="https://static.wikia.nocookie.net/villainous-benchmark/images/f/fa/Season_4_-_Jesse.webp/revision/latest/scale-to-width/360?cb=20240429123939" />
            <div class="container">
              <h2>Kushal Singh Sijapati</h2>
              <p class="title">Back end Designer</p>
              <p>3rd Year at Himalaya College of Engineering</p>
              <p>sijakushal20@gmail.com</p>
              <p>
                <button class="button">Contact</button>
              </p>
            </div>
          </div>
        </div>

        <div class="column">
          <div class="card">
            <img
              src="https://static.wikia.nocookie.net/villainous-benchmark/images/f/fa/Season_4_-_Jesse.webp/revision/latest/scale-to-width/360?cb=20240429123939"
              alt="John"
            />
            <div class="container">
              <h2>Sunil Bhandari</h2>
              <p class="title">Back end Designer</p>
              <p>3rd Year at Himalaya College of Engineering</p>
              <p>bhandarisunil6@gmail.com</p>
              <p>
                <button class="button">Contact</button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
