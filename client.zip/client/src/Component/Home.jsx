import React from "react";

const Home = () => {
  return (
    <div>
      <header style={{ textAlign: "center", padding: "px" }}>
        <h1>Welcome to Hospidocs</h1>
        <p style={{ fontSize: "18px", color: "#131212" }}>
          Your one-stop solution for decentralizes medical records.Hospidocs
          provides you a clear and concise overview of the platform’s core
          features and benefits. We introduce you to the system as a secure and
          user-friendly solution for managing patient data, ensuring easy access
          to critical health information for healthcare professionals. The
          homepage highlights features like patient record management,
          prescription tracking, and real-time access to patient data. It also
          emphasizes the system's commitment to data privacy, security, and
          compliance with health regulations, ensuring patients' sensitive
          information is protected.
        </p>
      </header>
    </div>
  );
};

export default Home;
